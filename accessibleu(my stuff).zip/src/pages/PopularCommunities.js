import "./PopularCommunities.css"

function PopularCommunities(){
  return (
<div class="sidenav">
<h3>Popular Communities</h3>
<a href="#community 1">Community 1</a>
<a href="#community 2">Community 2</a>
<a href="#community 3">Community 3</a>
</div>
  )
     
  }
  
  export default PopularCommunities;

  //add min and max margin to make dynamic
  //@media for different sizes 